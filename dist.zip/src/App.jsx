import { Routes, Route, Navigate, useParams, useNavigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext.jsx';
import { Spin, Result } from 'antd';
import ProtectedRoute from './components/layout/ProtectedRoute.jsx';
import AppLayout from './components/layout/AppLayout.jsx';

// Pages
import Login from './pages/auth/Login.jsx';
import ChangePassword from './pages/auth/ChangePassword.jsx';
import ForgotPassword from './pages/auth/ForgotPassword.jsx';
import ResetPassword from './pages/auth/ResetPassword.jsx';
import UserManagement from './pages/system/UserManagement.jsx';
import RecycleBin from './pages/system/RecycleBin.jsx';
import CustomerMaster from './pages/masters/CustomerMaster.jsx';
import WalletManagementPage from './pages/wallet/WalletManagementPage.jsx';
import HomeBannerPage from './pages/web-management/HomeBannerPage.jsx';
import WebCategoryPage from './pages/web-management/WebCategoryPage.jsx';
import TestimonialPage from './pages/web-management/TestimonialPage.jsx';
import VideoTestimonialPage from './pages/web-management/VideoTestimonialPage.jsx';
import SiteSettingsPage from './pages/web-management/SiteSettingsPage.jsx';
import MarqueePage from './pages/web-management/MarqueePage.jsx';
import DeliveryPincodePage from './pages/web-management/DeliveryPincodePage.jsx';
import PincodeRequestsPage from './pages/web-management/PincodeRequestsPage.jsx';
import TileRoomPage from './pages/web-management/TileRoomPage.jsx';
import TileTypePage from './pages/web-management/TileTypePage.jsx';
import TileSizePage from './pages/web-management/TileSizePage.jsx';
import CategorySetup from './pages/masters/CategorySetup.jsx';
import ProductMaster from './pages/masters/ProductMaster.jsx';
import PriceListPage from './pages/masters/PriceListPage.jsx';
import DealerProductPricingPage from './pages/masters/DealerProductPricingPage.jsx';
import DealerMaster from './pages/masters/DealerMaster.jsx';
import DealerTypePage from './pages/masters/DealerTypePage.jsx';
import DealerCategoryPage from './pages/masters/DealerCategoryPage.jsx';
import RegionPage from './pages/masters/RegionPage.jsx';
import RoutePage from './pages/masters/RoutePage.jsx';
import SupplierMaster from './pages/masters/SupplierMaster.jsx';
import WarehousePage from './pages/masters/WarehousePage.jsx';
import BranchPage from './pages/masters/BranchPage.jsx';
import ExpenseCategoryPage from './pages/masters/ExpenseCategoryPage.jsx';
import SalesOrderDashboard from './pages/sales/SalesOrderDashboard.jsx';
import SalesReturnPage from './pages/sales/SalesReturnPage.jsx';
import WebsiteOrders from './pages/sales/WebsiteOrders.jsx';
import SalesOrderView from './pages/sales/SalesOrderView.jsx';
import DealerPaymentsPage from './pages/sales/DealerPaymentsPage.jsx';
import PurchaseOrderPage from './pages/purchase/PurchaseOrderPage.jsx';
import GRNEntryPage from './pages/purchase/GRNEntryPage.jsx';
import PurchaseRequisition from './pages/purchase/PurchaseRequisition.jsx';
import SupplierQuotationPage from './pages/purchase/SupplierQuotationPage.jsx';
import SupplierPaymentsPage from './pages/purchase/SupplierPaymentsPage.jsx';
import SupplierInvoicePage from './pages/purchase/SupplierInvoicePage.jsx';
import StockPage from './pages/inventory/StockPage.jsx';
import StockAdjustmentPage from './pages/inventory/StockAdjustmentPage.jsx';
import StockTransferPage from './pages/inventory/StockTransferPage.jsx';
import PurchaseReturnPage from './pages/purchase/PurchaseReturnPage.jsx';
import QuotationManager from './pages/sales/QuotationManager.jsx';
import DiscountMappingPage from './pages/sales/DiscountMappingPage.jsx';
import InvoiceManager from './pages/sales/InvoiceManager.jsx';
import PickingListPage from './pages/warehouse/PickingListPage.jsx';
import DispatchPlanningPage from './pages/warehouse/DispatchPlanningPage.jsx';
import DeliveryTrackingPage from './pages/warehouse/DeliveryTrackingPage.jsx';
import SupplierSchemePage from './pages/purchase/SupplierSchemePage.jsx';
import BankReconciliationPage from './pages/finance/BankReconciliationPage.jsx';
import AdvancedReportsPage from './pages/reports/AdvancedReportsPage.jsx';
import BarcodeLabelPage from './pages/inventory/BarcodeLabelPage.jsx';
import TileCalculatorPage from './pages/tools/TileCalculatorPage.jsx';
import TaskManagementPage from './pages/system/TaskManagementPage.jsx';
import DocumentManagementPage from './pages/system/DocumentManagementPage.jsx';
import NotificationTemplatePage from './pages/system/NotificationTemplatePage.jsx';
import NotificationSettingsPage from './pages/system/NotificationSettingsPage.jsx';
import NotificationInboxPage from './pages/system/NotificationInboxPage.jsx';
import AccessPolicyPage from './pages/system/AccessPolicyPage.jsx';
import DealerAppAccess from './pages/system/DealerAppAccess.jsx';
import SystemHealth from './pages/system/SystemHealth.jsx';
import RolesPermissions from './pages/system/RolesPermissions.jsx';

// Finance Pages
import DealerLedger from './pages/finance/DealerLedger.jsx';
import SupplierLedger from './pages/finance/SupplierLedger.jsx';
import ChequeManagement from './pages/finance/ChequeManagement.jsx';
import VoucherEntry from './pages/finance/VoucherEntry.jsx';
import CashBankBook from './pages/finance/CashBankBook.jsx';

// Week 8 — Dispatch, Warehouse, CRM, Complaints, Approvals
import DispatchPlanning from './pages/dispatch/DispatchPlanning.jsx';
import PickingList from './pages/warehouse/PickingList.jsx';
import SortingList from './pages/warehouse/SortingList.jsx';
import LoadingVerification from './pages/warehouse/LoadingVerification.jsx';
import LeadManagement from './pages/crm/LeadManagement.jsx';
import SELeadApp from './pages/crm/SELeadApp.jsx';
import Customer360 from './pages/crm/Customer360.jsx';
import ComplaintDashboard from './pages/complaints/ComplaintDashboard.jsx';
import ApprovalWorkflow from './pages/approvals/ApprovalWorkflow.jsx';

// Week 9+10 — Dashboard, Reports, Schemes
import OwnerDashboard from './pages/dashboard/OwnerDashboard.jsx';
import SalesReports from './pages/reports/SalesReports.jsx';
import PurchaseReports from './pages/reports/PurchaseReports.jsx';
import InventoryReports from './pages/reports/InventoryReports.jsx';
import GSTReports from './pages/reports/GSTReports.jsx';
import AgingReport from './pages/reports/AgingReport.jsx';
import BillWiseProfit from './pages/reports/BillWiseProfit.jsx';
import DeviationReport from './pages/reports/DeviationReport.jsx';
import DealerPerformance from './pages/reports/DealerPerformance.jsx';
import FinanceStatements from './pages/reports/FinanceStatements.jsx';
import HRReports from './pages/reports/HRReports.jsx';
import ActivityLogs from './pages/reports/ActivityLogs.jsx';
import SEPerformance from './pages/reports/SEPerformance.jsx';
import SupplierPerformance from './pages/reports/SupplierPerformance.jsx';
import BranchPerformance from './pages/reports/BranchPerformance.jsx';
import WarehousePerformance from './pages/reports/WarehousePerformance.jsx';
import CollectionReport from './pages/reports/CollectionReport.jsx';
import ExpenseReport from './pages/reports/ExpenseReport.jsx';
import OutstandingReport from './pages/reports/OutstandingReport.jsx';
import SupplierSchemeEntry from './pages/schemes/SupplierSchemeEntry.jsx';
import SupplierSchemeAnalysis from './pages/schemes/SupplierSchemeAnalysis.jsx';
import SupplierClaimManagement from './pages/schemes/SupplierClaimManagement.jsx';
import SchemeReconciliation from './pages/schemes/SchemeReconciliation.jsx';
import DealerSchemeSetup from './pages/schemes/DealerSchemeSetup.jsx';
import DealerPointsTracker from './pages/schemes/DealerPointsTracker.jsx';

// Finance extra pages
import BankAccountMaster from './pages/finance/BankAccountMaster.jsx';
import AccountMaster from './pages/finance/AccountMaster.jsx';
import Reconciliation from './pages/finance/Reconciliation.jsx';

// Masters extra
import VehicleMaster from './pages/masters/VehicleMaster.jsx';
import ShadeBatchRegistry from './pages/masters/ShadeBatchRegistry.jsx';
import DealerEmployeeTargets from './pages/masters/DealerEmployeeTargets.jsx';

// CRM extra
import FollowUpManager from './pages/crm/FollowUpManager.jsx';

// Complaints extra
import ComplaintResolution from './pages/complaints/ComplaintResolution.jsx';
import ReturnRequest from './pages/complaints/ReturnRequest.jsx';
import ComplaintWorkflowQueue from './pages/complaints/ComplaintWorkflowQueue.jsx';

// Inventory extra
import StockAlerts from './pages/inventory/StockAlerts.jsx';
import PhysicalAudit from './pages/inventory/PhysicalAudit.jsx';
import SampleManagement from './pages/inventory/SampleManagement.jsx';

// Finance extra (credit monitor)
import CreditDaysMonitor from './pages/finance/CreditDaysMonitor.jsx';

// Dispatch extra
import DeliveryAssignment from './pages/dispatch/DeliveryAssignment.jsx';
import DeliveryMonitoring from './pages/dispatch/DeliveryMonitoring.jsx';
import DeliveryHistory from './pages/dispatch/DeliveryHistory.jsx';

// HRMS Pages
import EmployeeRegistration from './pages/hrms/EmployeeRegistration.jsx';
import AttendanceDashboard from './pages/hrms/AttendanceDashboard.jsx';
import LeaveManagement from './pages/hrms/LeaveManagement.jsx';
import SalaryProcessing from './pages/hrms/SalaryProcessing.jsx';
import LoansAdvances from './pages/hrms/LoansAdvances.jsx';
import HRMSSettings from './pages/hrms/HRMSSettings.jsx';
import OvertimeCalculation from './pages/hrms/OvertimeCalculation.jsx';
import DailyWageWorkers from './pages/hrms/DailyWageWorkers.jsx';
import JobOpenings from './pages/hrms/JobOpenings.jsx';
import CandidatePipeline from './pages/hrms/CandidatePipeline.jsx';
import HRDocumentTemplates from './pages/hrms/HRDocumentTemplates.jsx';
import PerformanceAppraisal from './pages/hrms/PerformanceAppraisal.jsx';
import EmployeeExitManagement from './pages/hrms/EmployeeExitManagement.jsx';
import ExpenseManagement from './pages/finance/ExpenseManagement.jsx';

// Dealer App
import DealerOrderRequests from './pages/dealer-app/DealerOrderRequests.jsx';
import DealerSupportChat from './pages/dealer-app/DealerSupportChat.jsx';

// Assets
import AssetMaster from './pages/assets/AssetMaster.jsx';
import AssetAssignment from './pages/assets/AssetAssignment.jsx';
import AssetMaintenance from './pages/assets/AssetMaintenance.jsx';
import EmployeeAssetHistory from './pages/assets/EmployeeAssetHistory.jsx';

// SE App Admin Views
import SEAttendanceViewer from './pages/se-app/SEAttendanceViewer.jsx';
import SEDealerVisits from './pages/se-app/SEDealerVisits.jsx';
import SEDealerAssignment from './pages/se-app/SEDealerAssignment.jsx';
import SERoutePlan from './pages/se-app/SERoutePlan.jsx';
import SEDealerInsights from './pages/se-app/SEDealerInsights.jsx';
import SECollections from './pages/se-app/SECollections.jsx';
import SETargetManagement from './pages/se-app/SETargetManagement.jsx';
import SEExpenseViewer from './pages/se-app/SEExpenseViewer.jsx';
import SELiveTracking from './pages/se-app/SELiveTracking.jsx';

// DE App Admin Views
import DEAssignment from './pages/de-app/DEAssignment.jsx';
import DEMonitoring from './pages/de-app/DEMonitoring.jsx';
import DEMyDeliveries from './pages/de-app/DEMyDeliveries.jsx';
import DERoutePlan from './pages/de-app/DERoutePlan.jsx';
import DECollections from './pages/de-app/DECollections.jsx';
import DEHistory from './pages/de-app/DEHistory.jsx';

// Placeholder page component for modules not yet built
const PlaceholderPage = ({ title }) => (
  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
    <h1 className="text-2xl font-bold text-gray-800">{title}</h1>
    <p className="mt-2 text-gray-500">This module is under development.</p>
    <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-dashed border-gray-300">
      <p className="text-sm text-gray-400">Module content will appear here once implemented.</p>
    </div>
  </div>
);

const UnauthorizedPage = () => (
  <div className="bg-white rounded-xl shadow-sm border border-gray-200">
    <Result
      status="403"
      title="Access denied"
      subTitle="Your account does not have permission to access this page."
    />
  </div>
);

const OrderViewPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  return (
    <div className="p-0">
      <SalesOrderView orderId={id} onClose={() => navigate(-1)} />
    </div>
  );
};

const App = () => {
  const { isAuthenticated, loading, branchEpoch, user } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <Spin size="large" tip="Loading BDMTILES..." ><span /></Spin>
      </div>
    );
  }

  // Not authenticated — show login
  if (!isAuthenticated) {
    return (
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password/:token" element={<ResetPassword />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    );
  }

  if (user?.mustChangePassword) {
    return (
      <Routes>
        <Route path="/change-password" element={<ChangePassword />} />
        <Route path="*" element={<Navigate to="/change-password" replace />} />
      </Routes>
    );
  }

  // Authenticated — show app with layout
  return (
    <AppLayout key={branchEpoch}>
      <Routes>
        <Route path="/login" element={<Navigate to="/dashboard" replace />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password/:token" element={<ResetPassword />} />
        <Route path="/change-password" element={<ChangePassword />} />
        <Route path="/unauthorized" element={<UnauthorizedPage />} />

        {/* Dashboard */}
        <Route path="/dashboard"
          element={<ProtectedRoute requiredPermission="dashboard.view"><OwnerDashboard /></ProtectedRoute>} />

        {/* System Management */}
        <Route
          path="/system/users"
          element={
            <ProtectedRoute requiredPermission="users.manage">
              <UserManagement />
            </ProtectedRoute>
          }
        />
        <Route path="/system/recycle-bin" element={<ProtectedRoute requiredPermission="users.manage"><RecycleBin /></ProtectedRoute>} />
        <Route path="/notifications" element={<ProtectedRoute requiredPermission="notification.inbox"><NotificationInboxPage /></ProtectedRoute>} />
        <Route path="/system/notification-templates" element={<ProtectedRoute requiredRoles={['super_admin', 'owner']} requiredPermission="notification.manage"><NotificationTemplatePage /></ProtectedRoute>} />
        <Route path="/system/notification-settings" element={<ProtectedRoute requiredRoles={['super_admin', 'owner']} requiredPermission="notification.manage"><NotificationSettingsPage /></ProtectedRoute>} />
        <Route path="/system/access-policies" element={<ProtectedRoute requiredRoles={['super_admin', 'owner']} requiredPermission="access.policy.manage"><AccessPolicyPage /></ProtectedRoute>} />
        <Route path="/system/roles" element={<ProtectedRoute requiredPermission="users.manage"><RolesPermissions /></ProtectedRoute>} />
        <Route path="/system/dealer-app-access" element={<ProtectedRoute requiredPermission="dealer.app.manage"><DealerAppAccess /></ProtectedRoute>} />
        <Route path="/system/health" element={<ProtectedRoute requiredPermission="system.management"><SystemHealth /></ProtectedRoute>} />

        {/* Web Management (Storefront CMS) */}
        <Route path="/web-management/site-settings" element={<ProtectedRoute requiredPermission="webmanagement.manage"><SiteSettingsPage /></ProtectedRoute>} />
        <Route path="/web-management/top-bar" element={<ProtectedRoute requiredPermission="webmanagement.manage"><MarqueePage /></ProtectedRoute>} />
        <Route path="/web-management/banners" element={<ProtectedRoute requiredPermission="webmanagement.manage"><HomeBannerPage /></ProtectedRoute>} />
        <Route path="/web-management/categories" element={<ProtectedRoute requiredPermission="webmanagement.manage"><WebCategoryPage /></ProtectedRoute>} />
        <Route path="/web-management/pincodes" element={<ProtectedRoute requiredPermission="webmanagement.manage"><DeliveryPincodePage /></ProtectedRoute>} />
        <Route path="/web-management/pincode-requests" element={<ProtectedRoute requiredPermission="webmanagement.manage"><PincodeRequestsPage /></ProtectedRoute>} />
        <Route path="/web-management/tile-rooms" element={<ProtectedRoute requiredPermission="webmanagement.manage"><TileRoomPage /></ProtectedRoute>} />
        <Route path="/web-management/tile-types" element={<ProtectedRoute requiredPermission="webmanagement.manage"><TileTypePage /></ProtectedRoute>} />
        <Route path="/web-management/tile-sizes" element={<ProtectedRoute requiredPermission="webmanagement.manage"><TileSizePage /></ProtectedRoute>} />
        <Route path="/web-management/testimonials" element={<ProtectedRoute requiredPermission="webmanagement.manage"><TestimonialPage /></ProtectedRoute>} />
        <Route path="/web-management/video-testimonials" element={<ProtectedRoute requiredPermission="webmanagement.manage"><VideoTestimonialPage /></ProtectedRoute>} />

        {/* Master Management */}
        <Route
          path="/masters/products"
          element={
            <ProtectedRoute requiredPermission="product.master">
              <ProductMaster />
            </ProtectedRoute>
          }
        />
        <Route
          path="/masters/price-list"
          element={
            <ProtectedRoute requiredPermission="price.list">
              <PriceListPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/masters/dealer-product-pricing"
          element={
            <ProtectedRoute requiredPermission="dealer.discounts">
              <DealerProductPricingPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/masters/categories"
          element={
            <ProtectedRoute requiredPermission="category.setup">
              <CategorySetup />
            </ProtectedRoute>
          }
        />
        <Route
          path="/masters/dealer-type"
          element={
            <ProtectedRoute requiredPermission="dealer.type">
              <DealerTypePage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/masters/dealer-category"
          element={
            <ProtectedRoute requiredPermission="dealer.category">
              <DealerCategoryPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/masters/expense-category"
          element={
            <ProtectedRoute requiredPermission="expense.category">
              <ExpenseCategoryPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/masters/regions"
          element={
            <ProtectedRoute requiredPermission="region.master">
              <RegionPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/masters/routes"
          element={
            <ProtectedRoute requiredPermission="route.master">
              <RoutePage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/masters/branch-master"
          element={
            <ProtectedRoute requiredPermission="branch.master">
              <BranchPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/masters/warehouse-master"
          element={
            <ProtectedRoute requiredPermission="warehouse.master">
              <WarehousePage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/masters/dealers"
          element={
            <ProtectedRoute requiredPermission="dealer.master">
              <DealerMaster />
            </ProtectedRoute>
          }
        />
        <Route
          path="/masters/suppliers"
          element={
            <ProtectedRoute requiredPermission="supplier.master">
              <SupplierMaster />
            </ProtectedRoute>
          }
        />
        <Route path="/masters/customers" element={<ProtectedRoute requiredPermission="customer.master"><CustomerMaster /></ProtectedRoute>} />
        <Route path="/masters/wallets" element={<ProtectedRoute requiredPermission="wallet.manage"><WalletManagementPage /></ProtectedRoute>} />
        <Route path="/masters/vehicles" element={<ProtectedRoute requiredPermission="vehicle.master"><VehicleMaster /></ProtectedRoute>} />
        <Route path="/masters/shade-batch-registry" element={<ProtectedRoute requiredPermission="stock.view"><ShadeBatchRegistry /></ProtectedRoute>} />
        <Route
          path="/masters/dealer-employee-targets"
          element={
            <ProtectedRoute requiredPermission="dealer.master">
              <DealerEmployeeTargets />
            </ProtectedRoute>
          }
        />

        {/* Sales & Purchase */}
        <Route
          path="/sales-purchase/sales-order-dashboard"
          element={
            <ProtectedRoute requiredPermission="sales.order.dashboard">
              <SalesOrderDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/sales-purchase/website-orders"
          element={
            <ProtectedRoute requiredPermission="sales.order.dashboard">
              <WebsiteOrders />
            </ProtectedRoute>
          }
        />
        <Route
          path="/sales-purchase/order-view/:id"
          element={
            <ProtectedRoute requiredPermission="sales.order.dashboard">
              <OrderViewPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/sales-purchase/discount-mapping"
          element={
            <ProtectedRoute requiredPermission="dealer.discounts">
              <DiscountMappingPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/sales-purchase/po-management"
          element={
            <ProtectedRoute requiredAnyPermissions={['po.management', 'po.approve']}>
              <PurchaseOrderPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/sales-purchase/grn-entry"
          element={
            <ProtectedRoute requiredPermission="grn.entry">
              <GRNEntryPage />
            </ProtectedRoute>
          }
        />
        <Route path="/sales-purchase/dealer-invoice" element={<Navigate to="/sales-purchase/invoices" replace />} />
        <Route
          path="/sales-purchase/supplier-invoice"
          element={
            <ProtectedRoute requiredPermission="invoice">
              <SupplierInvoicePage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/sales-purchase/supplier-payments"
          element={
            <ProtectedRoute requiredPermission="payment">
              <SupplierPaymentsPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/sales-purchase/dealer-payments"
          element={
            <ProtectedRoute requiredPermission="payment">
              <DealerPaymentsPage />
            </ProtectedRoute>
          }
        />
        <Route path="/sales-purchase/debit-note" element={<Navigate to="/sales-purchase/purchase-return" replace />} />
        <Route
          path="/sales-purchase/purchase-return"
          element={
            <ProtectedRoute requiredPermission="debit.note">
              <PurchaseReturnPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/sales-purchase/credit-note"
          element={
            <ProtectedRoute requiredPermission="credit.note">
              <SalesReturnPage />
            </ProtectedRoute>
          }
        />

        {/* Inventory & Warehouse */}
        <Route
          path="/inventory/stock"
          element={
            <ProtectedRoute requiredPermission="stock.view">
              <StockPage />
            </ProtectedRoute>
          }
        />
        <Route
          path="/inventory/stock-adjustment"
          element={
            <ProtectedRoute requiredAnyPermissions={['stock.adjustment.create', 'stock.adjustment.submit', 'stock.adjustment.approve', 'stock.adjustment.reverse', 'stock.adjustment']}>
              <StockAdjustmentPage />
            </ProtectedRoute>
          }
        />

        {/* HRMS */}
        <Route
          path="/hrms/employee-registration"
          element={
            <ProtectedRoute requiredPermission="employee.registration">
              <EmployeeRegistration />
            </ProtectedRoute>
          }
        />
        <Route
          path="/hrms/geo-attendance"
          element={
            <ProtectedRoute requiredPermission="attendance.master">
              <AttendanceDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/hrms/attendance-master"
          element={
            <ProtectedRoute requiredPermission="attendance.master">
              <AttendanceDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/hrms/shift-management"
          element={
            <ProtectedRoute requiredPermission="attendance.master">
              <HRMSSettings />
            </ProtectedRoute>
          }
        />
        <Route
          path="/hrms/leave-management"
          element={
            <ProtectedRoute requiredPermission="attendance.master">
              <LeaveManagement />
            </ProtectedRoute>
          }
        />
        <Route
          path="/hrms/salary-processing"
          element={
            <ProtectedRoute requiredPermission="salary.management">
              <SalaryProcessing />
            </ProtectedRoute>
          }
        />
        <Route
          path="/hrms/generate-salary-slip"
          element={
            <ProtectedRoute requiredPermission="salary.management">
              <SalaryProcessing />
            </ProtectedRoute>
          }
        />
        <Route
          path="/hrms/loans-advances"
          element={
            <ProtectedRoute requiredPermission="salary.management">
              <LoansAdvances />
            </ProtectedRoute>
          }
        />

        {/* Finance & Accounts */}
        <Route path="/finance/dealer-ledger"
          element={<ProtectedRoute requiredPermission="dealer.ledger"><DealerLedger /></ProtectedRoute>} />
        <Route path="/finance/supplier-ledger"
          element={<ProtectedRoute requiredPermission="supplier.ledger"><SupplierLedger /></ProtectedRoute>} />
        <Route path="/finance/cheque-management"
          element={<ProtectedRoute requiredPermission="cheque.view"><ChequeManagement /></ProtectedRoute>} />
        <Route path="/finance/voucher-entry"
          element={<ProtectedRoute requiredPermission="finance.management"><VoucherEntry /></ProtectedRoute>} />
        <Route path="/finance/bank-account-master"
          element={<ProtectedRoute requiredPermission="finance.management"><BankAccountMaster /></ProtectedRoute>} />
        <Route path="/finance/cash-bank-book"
          element={<ProtectedRoute requiredPermission="finance.management"><CashBankBook /></ProtectedRoute>} />
        <Route path="/finance/payment-allocation" element={<Navigate to="/sales-purchase/dealer-payments" replace />} />
        <Route path="/finance/auto-reconciliation"
          element={<ProtectedRoute requiredPermission="reconciliation"><Reconciliation /></ProtectedRoute>} />
        <Route
          path="/finance/account-master"
          element={
            <ProtectedRoute requiredPermission="finance.management">
              <AccountMaster />
            </ProtectedRoute>
          }
        />

        {/* Supplier Incentive Schemes */}
        <Route path="/supplier-incentive/scheme-entry" element={<ProtectedRoute requiredPermission="scheme.entry"><SupplierSchemeEntry /></ProtectedRoute>} />
        <Route path="/supplier-incentive/scheme-analysis" element={<ProtectedRoute requiredPermission="scheme.analysis"><SupplierSchemeAnalysis /></ProtectedRoute>} />
        <Route path="/supplier-incentive/claim-submission" element={<ProtectedRoute requiredPermission="claim.submission"><SupplierClaimManagement /></ProtectedRoute>} />
        <Route path="/supplier-incentive/reconciliation" element={<ProtectedRoute requiredPermission="incentive.reconciliation"><SchemeReconciliation /></ProtectedRoute>} />

        {/* Dealer Schemes */}
        <Route path="/dealer-app/scheme-setup" element={<ProtectedRoute requiredPermission="scheme.analysis"><DealerSchemeSetup /></ProtectedRoute>} />
        <Route path="/dealer-app/points-tracker" element={<ProtectedRoute requiredPermission="scheme.analysis"><DealerPointsTracker /></ProtectedRoute>} />

        {/* Dealer App */}
        <Route
          path="/dealer-app/support-chat"
          element={
            <ProtectedRoute requiredPermission="support.chat">
              <DealerSupportChat />
            </ProtectedRoute>
          }
        />
        <Route
          path="/dealer-app/order-requests"
          element={
            <ProtectedRoute requiredPermission="dealer.order_request.review">
              <DealerOrderRequests />
            </ProtectedRoute>
          }
        />

        {/* Sales Executive App */}
        <Route path="/se-app/attendance" element={<ProtectedRoute requiredPermission="attendance.master"><SEAttendanceViewer /></ProtectedRoute>} />
        <Route path="/se-app/live-tracking" element={<ProtectedRoute requiredPermission="se.attendance.view"><SELiveTracking /></ProtectedRoute>} />
        <Route path="/se-app/dealer-visits" element={<ProtectedRoute requiredPermission="se.attendance.view"><SEDealerVisits /></ProtectedRoute>} />
        {/* Reads the dealer list (dealer.master) and writes assignments
            (dealer.assignment.manage) — any-of, matching the two endpoints it calls. */}
        <Route path="/se-app/dealer-assignment" element={<ProtectedRoute requiredAnyPermissions={['dealer.master', 'dealer.assignment.manage']}><SEDealerAssignment /></ProtectedRoute>} />
        <Route path="/se-app/route-plan" element={<ProtectedRoute requiredPermission="route.master"><SERoutePlan /></ProtectedRoute>} />
        <Route path="/se-app/dealer-insights" element={<ProtectedRoute requiredPermission="reports.sales"><SEDealerInsights /></ProtectedRoute>} />
        <Route path="/se-app/collections" element={<ProtectedRoute requiredPermission="payment"><SECollections /></ProtectedRoute>} />
        {/* Authoring screen, not the executive's own view — gated on the incentive rule
            permission the /targets API enforces, so an SE cannot set their own target. */}
        <Route path="/se-app/targets" element={<ProtectedRoute requiredPermission="incentive.rules.view"><SETargetManagement /></ProtectedRoute>} />
        <Route path="/se-app/expenses" element={<ProtectedRoute requiredPermission="expense.management"><SEExpenseViewer /></ProtectedRoute>} />

        {/* Delivery Executive App */}
        <Route path="/de-app/assignment" element={<ProtectedRoute requiredPermission="de.assignment.manage"><DEAssignment /></ProtectedRoute>} />
        <Route path="/de-app/monitoring" element={<ProtectedRoute requiredPermission="de.monitoring.view"><DEMonitoring /></ProtectedRoute>} />
        <Route path="/de-app/my-deliveries" element={<ProtectedRoute requiredPermission="de.deliveries.view"><DEMyDeliveries /></ProtectedRoute>} />
        <Route path="/de-app/live-tracking" element={<ProtectedRoute requiredPermission="de.tracking.view"><PlaceholderPage title="DE Live Tracking — Phase 2 (Socket.io)" /></ProtectedRoute>} />
        <Route path="/de-app/route-plan" element={<ProtectedRoute requiredPermission="de.route.view"><DERoutePlan /></ProtectedRoute>} />
        <Route path="/de-app/collections" element={<ProtectedRoute requiredPermission="de.collections.view"><DECollections /></ProtectedRoute>} />
        <Route path="/de-app/history" element={<ProtectedRoute requiredPermission="de.history.view"><DEHistory /></ProtectedRoute>} />

        {/* Inventory — additional */}
        <Route path="/inventory/physical-audit" element={<ProtectedRoute requiredAnyPermissions={['stock.audit.create', 'stock.audit.count', 'stock.audit.submit', 'stock.audit.approve', 'stock.audit.reverse']}><PhysicalAudit /></ProtectedRoute>} />
        <Route path="/inventory/stock-alerts" element={<ProtectedRoute requiredPermission="stock.view"><StockAlerts /></ProtectedRoute>} />
        <Route path="/inventory/samples" element={<ProtectedRoute requiredPermission="stock.view"><SampleManagement /></ProtectedRoute>} />

        {/* Warehouse Operations — handled by new pages below */}
        <Route path="/warehouse/sorting-list" element={<ProtectedRoute requiredPermission="sorting.management"><SortingList /></ProtectedRoute>} />
        <Route path="/warehouse/loading-verification" element={<ProtectedRoute requiredPermission="dispatch.management"><LoadingVerification /></ProtectedRoute>} />

        {/* Dispatch & Delivery */}
        <Route path="/dispatch/delivery-assignment" element={<ProtectedRoute requiredPermission="dispatch.management"><DeliveryAssignment /></ProtectedRoute>} />
        <Route path="/dispatch/delivery-monitoring" element={<ProtectedRoute requiredPermission="dispatch.management"><DeliveryMonitoring /></ProtectedRoute>} />
        <Route path="/dispatch/delivery-history" element={<ProtectedRoute requiredPermission="dispatch.management"><DeliveryHistory /></ProtectedRoute>} />
        <Route path="/dispatch/live-tracking" element={<ProtectedRoute requiredPermission="dispatch.management"><PlaceholderPage title="Live Tracking" /></ProtectedRoute>} />
        <Route path="/dispatch/route-optimization" element={<ProtectedRoute requiredPermission="dispatch.management"><PlaceholderPage title="Route Optimization" /></ProtectedRoute>} />

        {/* CRM */}
        <Route path="/crm/lead-management" element={<ProtectedRoute requiredPermission="lead.view"><LeadManagement /></ProtectedRoute>} />
        <Route path="/se-app/leads" element={<ProtectedRoute requiredPermission="lead.app"><SELeadApp /></ProtectedRoute>} />
        <Route path="/crm/followup-manager" element={<ProtectedRoute requiredPermission="lead.followup"><FollowUpManager /></ProtectedRoute>} />
        <Route path="/crm/customer-360" element={<ProtectedRoute requiredPermission="lead.view"><Customer360 /></ProtectedRoute>} />

        {/* Complaints & Returns */}
        <Route path="/complaints/dashboard" element={<ProtectedRoute requiredPermission="complaint.management"><ComplaintDashboard /></ProtectedRoute>} />
        <Route path="/complaints/return-request" element={<ProtectedRoute requiredPermission="complaint.management"><ReturnRequest /></ProtectedRoute>} />
        <Route path="/complaints/warehouse-queue" element={<ProtectedRoute requiredPermission="warehouse.verification"><ComplaintWorkflowQueue mode="warehouse" /></ProtectedRoute>} />
        <Route path="/complaints/finance-queue" element={<ProtectedRoute requiredPermission="finance.management"><ComplaintWorkflowQueue mode="finance" /></ProtectedRoute>} />
        <Route path="/complaints/resolution" element={<ProtectedRoute requiredPermission="finance.management"><ComplaintResolution /></ProtectedRoute>} />

        {/* Assets */}
        <Route path="/assets/master" element={<ProtectedRoute requiredPermission="asset.management"><AssetMaster /></ProtectedRoute>} />
        <Route path="/assets/assignment" element={<ProtectedRoute requiredPermission="asset.management"><AssetAssignment /></ProtectedRoute>} />
        <Route path="/assets/employee-history" element={<ProtectedRoute requiredPermission="asset.management"><EmployeeAssetHistory /></ProtectedRoute>} />
        <Route path="/assets/maintenance" element={<ProtectedRoute requiredPermission="asset.management"><AssetMaintenance /></ProtectedRoute>} />

        {/* HRMS — additional */}
        <Route path="/hrms/overtime-calculation" element={<ProtectedRoute requiredPermission="attendance.master"><OvertimeCalculation /></ProtectedRoute>} />
        <Route path="/hrms/daily-wage-workers" element={<ProtectedRoute requiredPermission="attendance.master"><DailyWageWorkers /></ProtectedRoute>} />
        <Route path="/hrms/settings" element={<ProtectedRoute requiredPermission="hrms.management"><HRMSSettings /></ProtectedRoute>} />
        <Route path="/hrms/job-openings" element={<ProtectedRoute requiredPermission="job.opening.manage"><JobOpenings /></ProtectedRoute>} />
        <Route path="/hrms/candidate-pipeline" element={<ProtectedRoute requiredPermission="candidate.manage"><CandidatePipeline /></ProtectedRoute>} />
        <Route path="/hrms/document-templates" element={<ProtectedRoute requiredPermission="hr.template.manage"><HRDocumentTemplates /></ProtectedRoute>} />
        <Route path="/hrms/performance" element={<ProtectedRoute requiredPermission="performance.appraisal"><PerformanceAppraisal /></ProtectedRoute>} />
        <Route path="/hrms/employee-exit" element={<ProtectedRoute requiredPermission="employee.exit"><EmployeeExitManagement /></ProtectedRoute>} />

        {/* Finance — additional */}
        <Route path="/finance/credit-days-monitor" element={<ProtectedRoute requiredPermission="finance.management"><CreditDaysMonitor /></ProtectedRoute>} />
        <Route path="/finance/expense-management" element={<ProtectedRoute requiredPermission="finance.management"><ExpenseManagement /></ProtectedRoute>} />

        {/* Sales & Purchase — additional */}
        <Route path="/sales-purchase/quotation-manager" element={<ProtectedRoute requiredPermission="quotation.management"><QuotationManager /></ProtectedRoute>} />
        <Route path="/sales-purchase/invoices" element={<ProtectedRoute requiredPermission="invoice"><InvoiceManager /></ProtectedRoute>} />
        <Route path="/inventory/stock-transfers" element={<ProtectedRoute requiredPermission="stock.transfer"><StockTransferPage /></ProtectedRoute>} />
        <Route path="/warehouse/picking-list" element={<ProtectedRoute requiredPermission="picking.management"><PickingListPage /></ProtectedRoute>} />
        <Route path="/warehouse/dispatch-planning" element={<ProtectedRoute requiredPermission="dispatch.management"><DispatchPlanningPage /></ProtectedRoute>} />
        <Route path="/warehouse/delivery-tracking" element={<ProtectedRoute requiredAnyPermissions={['delivery.view', 'delivery.tracking']}><DeliveryTrackingPage /></ProtectedRoute>} />
        <Route path="/sales-purchase/supplier-schemes" element={<ProtectedRoute requiredPermission="scheme.entry"><SupplierSchemePage /></ProtectedRoute>} />
        <Route path="/finance/bank-reconciliation" element={<ProtectedRoute requiredPermission="reconciliation"><BankReconciliationPage /></ProtectedRoute>} />
        <Route path="/reports/advanced" element={<ProtectedRoute requiredPermission="reports.profit"><AdvancedReportsPage /></ProtectedRoute>} />
        <Route path="/inventory/barcode-labels" element={<ProtectedRoute requiredPermission="stock.view"><BarcodeLabelPage /></ProtectedRoute>} />
        <Route path="/tools/tile-calculator" element={<ProtectedRoute requiredPermission="dashboard.view"><TileCalculatorPage /></ProtectedRoute>} />
        <Route path="/system/tasks" element={<ProtectedRoute requiredPermission="task.management"><TaskManagementPage /></ProtectedRoute>} />
        <Route path="/system/documents" element={<ProtectedRoute requiredPermission="document.management"><DocumentManagementPage /></ProtectedRoute>} />
        <Route path="/system/notifications" element={<Navigate to="/system/notification-templates" replace />} />
        <Route path="/sales-purchase/purchase-requisition" element={<ProtectedRoute requiredAnyPermissions={['po.management', 'po.approve']}><PurchaseRequisition /></ProtectedRoute>} />
        <Route path="/sales-purchase/supplier-quotations" element={<ProtectedRoute requiredAnyPermissions={['po.management', 'po.approve']}><SupplierQuotationPage /></ProtectedRoute>} />

        {/* Reports — additional */}
        <Route path="/reports/sales-reports" element={<ProtectedRoute requiredPermission="reports.sales"><SalesReports /></ProtectedRoute>} />
        <Route path="/reports/purchase-reports" element={<ProtectedRoute requiredPermission="reports.purchase"><PurchaseReports /></ProtectedRoute>} />
        <Route path="/reports/inventory-reports" element={<ProtectedRoute requiredPermission="reports.inventory"><InventoryReports /></ProtectedRoute>} />
        <Route path="/reports/hr-reports" element={<ProtectedRoute requiredPermission="reports.hr"><HRReports /></ProtectedRoute>} />
        <Route path="/reports/se-performance" element={<ProtectedRoute requiredPermission="reports.sales"><SEPerformance /></ProtectedRoute>} />
        <Route path="/reports/cash-flow" element={<ProtectedRoute requiredPermission="reports.finance"><FinanceStatements /></ProtectedRoute>} />
        {/* Gated on 'reconciliation', not 'reports.finance': this route renders the live
            BankReconciliationPage, whose every API call requires 'reconciliation'. Gating it
            on reports.finance would let a user in to a page that 403s on load. */}
        <Route path="/reports/bank-reconciliation" element={<ProtectedRoute requiredPermission="reconciliation"><BankReconciliationPage /></ProtectedRoute>} />
        <Route path="/reports/gst-reports" element={<ProtectedRoute requiredPermission="reports.gst"><GSTReports /></ProtectedRoute>} />
        <Route path="/reports/aging-report" element={<ProtectedRoute requiredPermission="reports.finance"><AgingReport /></ProtectedRoute>} />
        {/* Audit & Activity Logs — one component, different slices of the ActivityLog action enum */}
        <Route path="/reports/audit-trail" element={<ProtectedRoute requiredPermission="audit.trail"><ActivityLogs
          title="Audit Trail"
          subtitle="Every recorded action with field-level before and after values. Expand a row to see what changed."
          showChanges
        /></ProtectedRoute>} />
        <Route path="/reports/activity-logs" element={<ProtectedRoute requiredPermission="activity.logs"><ActivityLogs
          title="Activity Logs"
          subtitle="Complete activity feed — who did what, when, from where. Auto-deletes after 60 days."
          allowCleanup
        /></ProtectedRoute>} />
        <Route path="/reports/login-history" element={<ProtectedRoute requiredPermission="audit.trail"><ActivityLogs
          title="Login History"
          subtitle="Sign-in and sign-out events, with IP address and device."
          actions={['login', 'logout']}
        /></ProtectedRoute>} />
        <Route path="/reports/user-activity" element={<ProtectedRoute requiredPermission="audit.trail"><ActivityLogs
          title="User Activity"
          subtitle="Activity per user — search by name to see everything one person did."
        /></ProtectedRoute>} />
        <Route path="/reports/data-modification" element={<ProtectedRoute requiredPermission="audit.trail"><ActivityLogs
          title="Data Modification History"
          subtitle="Create, update and delete events only. Expand a row for field-level old and new values."
          actions={['create', 'update', 'delete', 'restore', 'permanent_delete', 'bulk_update']}
          showChanges
        /></ProtectedRoute>} />
        <Route path="/reports/approval-history" element={<ProtectedRoute requiredPermission="audit.trail"><ActivityLogs
          title="Approval History"
          subtitle="Approve and reject decisions across every module."
          actions={['approve', 'reject']}
        /></ProtectedRoute>} />
        <Route path="/reports/download-logs" element={<ProtectedRoute requiredPermission="download.logs"><ActivityLogs
          title="Download Logs"
          subtitle="Documents and reports downloaded out of the system."
          actions={['download']}
        /></ProtectedRoute>} />
        <Route path="/reports/dealer-performance" element={<ProtectedRoute requiredPermission="reports.sales"><DealerPerformance /></ProtectedRoute>} />
        <Route path="/reports/supplier-performance" element={<ProtectedRoute requiredPermission="reports.purchase"><SupplierPerformance /></ProtectedRoute>} />
        <Route path="/reports/branch-performance" element={<ProtectedRoute requiredPermission="reports.sales"><BranchPerformance /></ProtectedRoute>} />
        <Route path="/reports/warehouse-performance" element={<ProtectedRoute requiredPermission="reports.inventory"><WarehousePerformance /></ProtectedRoute>} />
        <Route path="/reports/collection-report" element={<ProtectedRoute requiredPermission="reports.finance"><CollectionReport /></ProtectedRoute>} />
        <Route path="/reports/expense-report" element={<ProtectedRoute requiredAnyPermissions={['reports.finance', 'expense.management']}><ExpenseReport /></ProtectedRoute>} />
        <Route path="/reports/outstanding-report" element={<ProtectedRoute requiredPermission="reports.finance"><OutstandingReport /></ProtectedRoute>} />
        <Route path="/reports/balance-sheet" element={<ProtectedRoute requiredPermission="reports.finance"><FinanceStatements /></ProtectedRoute>} />
        <Route path="/reports/trial-balance" element={<ProtectedRoute requiredPermission="reports.finance"><FinanceStatements /></ProtectedRoute>} />
        <Route path="/reports/profit-loss" element={<ProtectedRoute requiredPermission="reports.finance"><FinanceStatements /></ProtectedRoute>} />
        <Route path="/reports/profit-analysis/bill-wise-profit" element={<ProtectedRoute requiredPermission="reports.profit"><BillWiseProfit /></ProtectedRoute>} />
        <Route path="/reports/profit-analysis/category-margin" element={<ProtectedRoute requiredPermission="reports.profit"><BillWiseProfit /></ProtectedRoute>} />
        <Route path="/reports/profit-analysis/deviation-report" element={<ProtectedRoute requiredPermission="reports.profit"><DeviationReport /></ProtectedRoute>} />

        {/* Approval Workflow */}
        <Route path="/approvals" element={<ProtectedRoute requiredAnyPermissions={['sales.order.approve', 'po.approve', 'finance.management', 'dealer.discounts', 'credit.note', 'debit.note', 'system.management']}><ApprovalWorkflow /></ProtectedRoute>} />

        {/* Fallback */}
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />      </Routes>
    </AppLayout>
  );
};

export default App;
